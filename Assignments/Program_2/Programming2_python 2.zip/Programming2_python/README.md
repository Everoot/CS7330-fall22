# README

To run this project, you can use the following to start.

For example 

```shell
python3 program2.py 3 t1.txt 
```

`python3` +`program2.py` +`<number of items in database>` + `<file1>` +`<file2>`+ `...`+`<transaction file n>`

![Screenshot 2022-12-08 at 17.32.19](./README.assets/Screenshot 2022-12-08 at 17.32.19.png)

<img src="./README.assets/Screenshot 2022-12-08 at 17.32.59.png" alt="Screenshot 2022-12-08 at 17.32.59" style="zoom: 50%;" />



The `program2_wait_die.py` same as before.

<img src="./README.assets/Screenshot 2022-12-08 at 17.34.32.png" alt="Screenshot 2022-12-08 at 17.34.32" style="zoom:50%;" />