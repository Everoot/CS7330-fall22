# README

* We offer some test datas in the `test.py` in the `blueprints` in code file. User can use that for the test.

* We also offer two ways to set up the database, if you want to use the local database just make sure the local database service start. 

  * If want online mongodb, should find `app.py` in the `Code` 

    ![Screenshot 2022-12-03 at 13.42.25](https://tva1.sinaimg.cn/large/008vxvgGgy1h8r8vt9ehsj314809uab1.jpg)

    you will use these code instead of ![Screenshot 2022-12-03 at 13.43.01](https://tva1.sinaimg.cn/large/008vxvgGgy1h8r8vtl95sj314809uab1.jpg)

* We just set default is using local databse.



