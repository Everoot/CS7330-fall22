from .entryinput import entry_input as enter
from .entryquery import entry_query as query
from .entrymodify import entry_modify as modify
from .entrydelete import entry_delete as delete
